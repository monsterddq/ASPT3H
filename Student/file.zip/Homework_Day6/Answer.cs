using System;

namespace Demo
{
    public class Answer : Learning
    {
        public string answer_code;
        public string content;
    }
}
