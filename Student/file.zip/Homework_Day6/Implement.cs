using System;
using System.Collections.Generic;

namespace Demo
{
    public class Implement : IQuestion
    {
        public void find (string question_code)
        {
            return;
        }

        public void addQuestion(Question q)
        {

        }

        public void modify(Question q)
        {
            return;
        }

        public void remove(Question q)
        {
            return;
        }

        public void getAll()
        {
            return;
        }
    }
}
