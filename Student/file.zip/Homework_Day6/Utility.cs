using System;

namespace Demo
{
    public static class Utility
    {
        public static List<Question>;
        public static List<Answer>;
        public static List<Result>;
    }
}
