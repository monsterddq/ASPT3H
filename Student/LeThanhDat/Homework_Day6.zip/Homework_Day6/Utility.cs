using System;
using System.Collections.Generic;

namespace Demo
{
    public static class Utility
    {
        public static List<Question> questions = new List<Question>();
        public static List<Answer> answers = new List<Answer>();
        public static List<Result> results = new List<Result>();
    }
}
