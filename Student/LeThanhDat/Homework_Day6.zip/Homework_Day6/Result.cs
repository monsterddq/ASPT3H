using System;

namespace Demo
{
    public class Result
    {
        string question_code;
        string[] correct_answer;
        string[] incorrect_answer;
}
