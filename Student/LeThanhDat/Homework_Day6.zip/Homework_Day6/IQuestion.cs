using System;
using System.Collections.Generic;

namespace Demo
{
    interface IQuestion
    {
        List<Question> getAll();
        Question find(string question_code);
        void addQuestion(Question q);
        void modify(string question_code);
        void remove(string question_code);
    }
}
