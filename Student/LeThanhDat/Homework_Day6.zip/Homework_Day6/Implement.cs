using System;
using System.Collections.Generic;

namespace Demo
{
    public class Implement : IQuestion, IAnswer
    {
        Question find(string question_code)
        {
            return this.GetAll().Find(w => w.question_code.Equals(question_code));
        }

        void addQuestion(Question q)
        {
            return Utility.questions.Add(q);
        }

        void modify(string question_code)
        {
            return;
        }

        void remove(string question_code)
        {
            Question q = find(question_code);
            Utility.questions.Remove(q);
        }

        List<Question> getAll()
        {
            return Utility.questions;
        }

        List<Answer> getAllQuestions()
        {
            return Utility.answers;
        }

        Answer addQuestion(Answer a)
        {
            return Utility.answers.Add();
        }

        Answer findAnswer(string code)
        {
            return this.getAllQuestions().Find(a => a.answer_code.Equals(code));
        }

        void modifyAnswer(string code)
        {
            return;
        }

        void removeAnswer(string code)
        {
            Answer a = findAnswer(code);
            Utility.answers.Remove(a);
        }
    }
}
