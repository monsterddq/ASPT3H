using System;
using System.Collections.Generic;

namespace Demo
{
    interface IQuestion
    {
        List<Answer> getAllAnswers();
        Answer addAnswer(Answer a);
        void modifyAnswer(string code);
        void removeAnswer(string code);
        Answer findAnswer(string code)
    }
}
