using System;
using System.Collections.Generic;
using System.Linq;

namespace Demo
{
    public class Program
    {
        public static void print_menu()
        {
            Console.WriteLine("1. Them cau hoi");
            Console.WriteLine("2. Lay ra tat ca cau hoi");
            Console.WriteLine("3. Sua cau hoi");
            Console.WriteLine("4. Xoa cau hoi");
            Console.WriteLine("5. Tim kiem cau hoi theo ma cau hoi");
            Console.WriteLine("6. Thoat chuong trinh");
        }

        public static void Main(string[] args)
        {
            string c = Console.ReadLine();
            IQuestion quiz = new Implement();
            while (true)
            {
                print_menu();
                switch (c)
                {
                    case "1":
                        Question q = new Question();
                        q.set_question_code(Guid.NewGuid().ToString());
                        q.set_content("I ___ fine.");
                        q.set_type(Convert.ToInt32(Console.ReadLine()));
                        q.set_level(Convert.ToInt32(Console.ReadLine()));
                        quiz.addQuestion(q);
                        break;
                    case "2":
                        foreach (var item in quiz.getAllQuestions())
                        {
                            Console.WriteLine(item);
                        }
                        break;
                    case "3":
                        Console.WriteLine("N/a");
                        break;
                    case "4":
                        Question q = find(Console.ReadLine());
                        if (q == null)
                        {
                            Console.WriteLine("Ma cau hoi khong hop le");
                        }
                        else
                        {
                            Console.WriteLine(q);
                        }
                        break;
                    case "5":
                        Question q = quiz.find(Console.ReadLine());
                        if (q == null)
                        {
                            Console.WriteLine("Ma cau hoi khong hop le");
                        }
                        else
                        {
                            quiz.remove(q);
                        }
                        break;
                    case "6":
                        do {
                            Console.WriteLine("Muon thoat khong?(Y/n)");
                            string str = Console.ReadLine();
                            if (str == "Y" || str == "y")
                            {
                                Environment.Exit(0);
                            }
                            else if (str == "N" || str == "n")
                            {
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Nhap khong hop le.");
                                break;
                            }
                        } while (str != "Y" || str != "y" || str != "n" || str != "N");
                        break;
                    default:
                        Console.WriteLine("Lua chon khong hop le. Xin thu lai");
                        break;
                }
            }
        }
    }
}
