using System;

namespace Demo
{
    public class Answer : Learning
    {
        public string answer_code;

        public void set_answer_code(string answer_code)
        {
            this.answer_code = answer_code;
        }

        public void set_content(string content)
        {
            this.content = content;
        }

        public string get_answer_code()
        {
            return answer_code;
        }

        public string get_content()
        {
            return content;
        }
    }
}
