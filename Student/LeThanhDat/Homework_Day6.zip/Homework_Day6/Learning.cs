using System;

namespace Demo
{
    public abstract class Learning
    {
        string content;
    }
}
