﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            public interface ICommonObject<T, K>
    {
        List<T> GetAll();
        void AddNew(T obj);
        void Modify(T obj);
        void Delete(K obj);
    }
    public abstract class AbstractCommon<T, K> : ICommonObject<T, K>
    {
        public void AddNew(T obj)
        {
            throw new NotImplementedException();
        }

        public void Delete(K obj)
        {
            throw new NotImplementedException();
        }

        public List<T> GetAll()
        {
            throw new NotImplementedException();
        }

        public void Modify(T obj)
        {
            throw new NotImplementedException();
        }
    }
    public class StudentServices : AbstractCommon<Student, int>
    {
        public void AddStudent()
        {
            Student objStudent = new Student();
            AddNew(objStudent);
        }
        public void ModifyStudent()
        {
            Student objStudent = new Student();
            Modify(objStudent);
        }
        public void DeleteStudent()
        {
            Student objStudent = new Student();
            Delete(objStudent.StudentId);
        }
        public List<Student> GetAllStudent()
        {
            return GetAll();
        }
      
    }
    public class LogServices : AbstractCommon<Log, int>
    {
        public void AddLog()
        {
            Log objLog = new Log();
            AddNew(objLog);
        }
        public void ModifyLog()
        {
            Log objLog = new Log();
            Modify(objLog);
        }
        public void DeleteLog()
        {
            Log objLog = new Log();
            Delete(objLog.LogId);
        }
        public List<Log> GetAllLog()
        {
            return GetAll();
        }
    }
        }
    }
}
