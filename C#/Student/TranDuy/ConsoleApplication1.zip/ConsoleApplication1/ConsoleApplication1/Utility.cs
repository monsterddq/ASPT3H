﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Utility
    {
        public static listStudent List<Student> = new List<Student>();
	    public static listLog List<Log> = new List<Log>();
    }
}
