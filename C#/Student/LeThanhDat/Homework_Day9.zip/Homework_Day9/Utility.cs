using System;
using System.Collections;

namespace Demo
{
    public static class Utility
    {
        public List<Student> listStudent = new List<Student>();
        public List<Log> listLog = new List<Log>();
    }
}
